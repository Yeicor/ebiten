void main(void) {
	if (true) {
		gl_FragColor = gl_FragCoord;
		return;
	}
	gl_FragColor = gl_FragCoord;
	return;
}
