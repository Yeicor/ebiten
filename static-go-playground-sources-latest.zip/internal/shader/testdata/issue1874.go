package main

func Foo() float {
	const (
		s = 0.1
		c = 0.2
	)
	return sin(s) + cos(c)
}
