package main

const F = float(1)

func Foo() float {
	return F
}

const I = int(2.0)

func Bar() int {
	return I
}
