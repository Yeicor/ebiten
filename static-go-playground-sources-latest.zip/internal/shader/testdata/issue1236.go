package main

func Foo(v vec4) vec4 {
	v2 := mat4(1) * v
	return v2
}
