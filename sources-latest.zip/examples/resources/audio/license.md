# License

## jab.wav

```
http://soundbible.com/995-Jab.html

Recorded by Mike Koenig
Attribution 3.0: https://creativecommons.org/licenses/by/3.0/
```

## jump.ogg

```
https://opengameart.org/content/jumping-man-sounds

CC0
```


## ragtime.ogg / ragtime.mp3

```
https://soundcloud.com/jacaranda-trilhas-sonoras/james-scott-01-frog-legs-rag

Title:  Frog Legs Rag (1906, piano roll)
Artist: James Scott
Album:  Frog Legs: Ragtime Era Favorites

Attribution-NonCommercial-ShareAlike: http://creativecommons.org/licenses/by-nc-sa/3.0/
```
